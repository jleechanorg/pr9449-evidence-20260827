# Methodology

This bundle was generated at exact git commit `d51c9127f82b1a9f650aec9a833db19fc9ee57c9` by
`testing_mcp/streaming/test_streaming_code_execution_deadline_evidence.py`.
The harness invokes the real Gemini SDK streaming path with model
`gemini-3-flash-preview`, applies the configured application deadline, and records the
observed cancellation request and acknowledgement without substituting a fake
provider or logging path. It then queries BigQuery for payload, event, and
latency rows correlated by request `req-deadline-41574030cb0c` and campaign `camp-deadline-fb40fa64`.

`--verify-only` checks exact-head provenance, every required artifact and its
checksum sidecar, the deadline bound, the explicit claim map, monotonic
cancellation telemetry, and cross-table request/campaign correlation. The PASS
claim is deliberately narrow: bounded application termination and truthful
persisted telemetry. It does not prove provider transport cleanup when
`cancellation_acknowledged` is false, nor raw model output for this deadline call.
