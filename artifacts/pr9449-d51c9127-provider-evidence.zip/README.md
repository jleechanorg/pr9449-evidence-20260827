# Provider Deadline Evidence Bundle

- Exact git commit: `d51c9127f82b1a9f650aec9a833db19fc9ee57c9`
- Provider: `gemini_sdk`
- Model: `gemini-3-flash-preview`
- Verdict: `PASS`

## Verify on a clean checkout

```bash
git checkout d51c9127f82b1a9f650aec9a833db19fc9ee57c9
EVIDENCE_DIR=/absolute/path/to/extracted/provider-evidence
./vpython testing_mcp/streaming/test_streaming_code_execution_deadline_evidence.py \
  --verify-only --evidence-dir "$EVIDENCE_DIR"
(cd "$EVIDENCE_DIR" && sha256sum -c SHA256SUMS)
```

See `methodology.md` for the method and claim boundary, `run.json` for the
machine-readable result, `evidence.md` for the claim-to-artifact map, and
`verification_report.json` for the deterministic verifier verdict.
