# Evidence Summary: streaming_disconnect_atomicity_evidence

## Test Results
- **Total Scenarios:** 3
- **Scenario Validation Passed:** 3
- **Scenario Validation Failed:** 0
- **Scenario Validation Pass Rate:** 100.0%
- **Raw LLM Layer Passed:** 2/2 (100.0%)

## ⚠️ Multi-Campaign Isolation Note

This evidence bundle contains **2 campaigns**:
- **0 shared campaign(s)** reused across multiple tests
- **2 independent campaign(s)** each used by one test only

**Why:** Each test uses its own campaign to prevent state bleed

**Claim Scoping:** Each scenario result below includes its `campaign_id`. Claims about
specific scenarios reference ONLY that scenario's campaign. Aggregate claims (e.g., "18/18 passed")
span all campaigns but each individual result is traceable to its campaign.

- **Post-Processing Campaign Capture Passed:** 2
- **Post-Processing Campaign Capture Failed:** 0
- **Post-Processing Campaign Capture Pass Rate:** 100.0%
## Scenario Results

### interrupted_response_continue
- **Status:** ✅ PASS
- **Campaign ID:** `6NrE2kxis7UirI2e0hM9`

### interrupted_response_retry
- **Status:** ✅ PASS
- **Campaign ID:** `TE7l8BEkkfxTtUYi5G2R`

### EVIDENCE_SIGNATURE_GUARD
- **Status:** ✅ PASS

## Provenance Chain
- **Git HEAD:** `72313a69e0c8938839e10d1c1b1966ef0206ed3c`
- **Test Timestamp:** `2026-08-31T05:01:55.073713+00:00`
- **Server PID:** `3950655`


## Claim → Artifact Map

| Claim | File | Key Field(s) |
|-------|------|--------------|
| Scenario validation passed: 3/3 | run.json | scenarios[*].passed, scenarios[*].errors |
| Campaign post-processing capture passed: 2/2 | run.json | campaign_capture_status[*].status |
| Streaming evidence normalized | streaming_evidence.json | summary.*, scenarios[*].chunk_count_observed |
| Bundle artifact inventory | artifacts/collection_log.txt | core_files, jsonl_captures, campaigns_dir |
| MCP request/response captured | request_responses.jsonl | Full request/response pairs |
| Local server HTTP request/response captured | http_request_responses.jsonl | http_request/http_response entries |
| LLM request/response stream captured | llm_request_responses.jsonl | request/response entries (type field) |
| Provider HTTP transport captured | provider_http_request_responses.jsonl | http_request/http_response/transport_error entries |
| Server execution log | artifacts/server.log | Raw server output |
| Git provenance | metadata.json | git_provenance.git_head = `72313a69...` |
| Test/harness-produced artifact: http_request_responses_1788152261381.jsonl | http_request_responses_1788152261381.jsonl | (see file for structure) |
| Test/harness-produced artifact: llm_request_responses_1788152261381.jsonl | llm_request_responses_1788152261381.jsonl | (see file for structure) |
| Test/harness-produced artifact: provider_http_request_responses_1788152261381.jsonl | provider_http_request_responses_1788152261381.jsonl | (see file for structure) |
| Test/harness-produced artifact: recovery_capture.json | recovery_capture.json | (see file for structure) |
| Test/harness-produced artifact: streaming_disconnect_atomicity_evidence.cast | streaming_disconnect_atomicity_evidence.cast | (see file for structure) |

## Coverage Matrix

| Scenario | Status | Campaign ID |
|----------|--------|-------------|
| interrupted_response_continue | ✅ Pass | `6NrE2kxi...` |
| interrupted_response_retry | ✅ Pass | `TE7l8BEk...` |
| EVIDENCE_SIGNATURE_GUARD | ✅ Pass | N/A |

## Evidence Integrity

- All files in this bundle have corresponding `.sha256` checksum files
- Checksums use local basename paths so per-file verification works from each artifact directory

- ⚠️ Server warnings detected (see artifacts/server.log)
- Warning: CRITICAL_SAFEGUARD


## What This Evidence Proves vs. Does NOT Prove

**Proves**:
- Core logic and scenario validation for streaming_disconnect_atomicity_evidence
- Scenario execution pass rates (3/3)

**Does NOT Prove**:
- Production server behavior (tested on local server unless otherwise noted)
- Performance under load (single-request tests)
- Edge cases not covered by scenarios

## Claim → Artifact Map (Post-Finalization Addendum)

Files below were written after create_evidence_bundle() returned and
are added here by finalize_late_evidence_artifacts() so every
top-level artifact is traceable from evidence.md.

| Claim | File | Key Field(s) |
|-------|------|--------------|
| Test/harness-produced artifact: replay_fixture_source_manifest.json | replay_fixture_source_manifest.json | (see file for structure) |
| Test/harness-produced artifact: test_console_output.txt | test_console_output.txt | (see file for structure) |
