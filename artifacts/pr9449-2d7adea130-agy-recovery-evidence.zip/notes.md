# Notes: streaming_disconnect_atomicity_evidence

## Run Information
- **Run ID:** `streaming_disconnect_atomicity_evidence-011-20260831T071246`
- **Iteration:** 11
- **Bundle Version:** 1.2.0
- **Timestamp:** 2026-08-31T07:12:46.376381+00:00

## Evidence Integrity
- All files in this bundle have corresponding `.sha256` checksum files
- Checksums use local basename paths so per-file verification works from each artifact directory

## Scenario Summary
- **Total:** 3
- **Passed:** 3
- **Failed:** 0

## Post-Processing Capture Summary
- **Campaigns with capture status:** 2
- **Capture Passed:** 2
- **Capture Failed:** 0

## Warning/Error Summary
- **Server Warnings:** 163 warnings in server.log
- **Warning Parser:** line-level regex `\bWARNING\b|SYSTEM WARNING:` (one count per matching line)
- **Key Warning Categories:**
  - CRITICAL_SAFEGUARD
  - INVENTORY_SAFEGUARD

## Follow-up Items
<!-- Add any follow-up items, TODOs, or observations here -->

## Additional Context
<!-- Add any additional context that helps understand this test run -->
