# Evidence Summary: recoverable_interrupted_response

## Test Results
- **Total Scenarios:** 3
- **Scenario Validation Passed:** 3
- **Scenario Validation Failed:** 0
- **Scenario Validation Pass Rate:** 100.0%
- **Raw LLM Layer Passed:** 0/3 (0.0%)

## Scenario Results

### reload_continue
- **Status:** ✅ PASS

### reload_retry
- **Status:** ✅ PASS

### completed_receipt_refresh
- **Status:** ✅ PASS

## Provenance Chain
- **Git HEAD:** `61e577b5d87b55b51da8b3e53607f0b002987d35`
- **Test Timestamp:** `2026-08-31T09:45:52.150452+00:00`
- **Server PID:** `4071805`


## Claim → Artifact Map

| Claim | File | Key Field(s) |
|-------|------|--------------|
| Scenario validation passed: 3/3 | run.json | scenarios[*].passed, scenarios[*].errors |
| Streaming evidence normalized | streaming_evidence.json | summary.*, scenarios[*].chunk_count_observed |
| Bundle artifact inventory | artifacts/collection_log.txt | core_files, jsonl_captures, campaigns_dir |
| MCP request/response captured | request_responses.jsonl | Full request/response pairs |
| Local server HTTP request/response captured | http_request_responses.jsonl | http_request/http_response entries |
| LLM request/response stream captured | llm_request_responses.jsonl | request/response entries (type field) |
| Provider HTTP transport captured | provider_http_request_responses.jsonl | http_request/http_response/transport_error entries |
| Server execution log | artifacts/server.log | Raw server output |
| Git provenance | metadata.json | git_provenance.git_head = `61e577b5...` |
| Test/harness-produced artifact: http_request_responses_1788169471782.jsonl | http_request_responses_1788169471782.jsonl | (see file for structure) |
| Test/harness-produced artifact: iteration_028_ui.mp4 | iteration_028_ui.mp4 | (see file for structure) |
| Test/harness-produced artifact: llm_request_responses_1788169471782.jsonl | llm_request_responses_1788169471782.jsonl | (see file for structure) |
| Test/harness-produced artifact: provider_http_request_responses_1788169471782.jsonl | provider_http_request_responses_1788169471782.jsonl | (see file for structure) |
| Test/harness-produced artifact: recovery_flow.vtt | recovery_flow.vtt | (see file for structure) |

## Coverage Matrix

| Scenario | Status | Campaign ID |
|----------|--------|-------------|
| reload_continue | ✅ Pass | N/A |
| reload_retry | ✅ Pass | N/A |
| completed_receipt_refresh | ✅ Pass | N/A |

## Evidence Integrity

- All files in this bundle have corresponding `.sha256` checksum files
- Checksums use local basename paths so per-file verification works from each artifact directory


## What This Evidence Proves vs. Does NOT Prove

**Proves**:
- Core logic and scenario validation for recoverable_interrupted_response
- Scenario execution pass rates (3/3)

**Does NOT Prove**:
- Production server behavior (tested on local server unless otherwise noted)
- Performance under load (single-request tests)
- Edge cases not covered by scenarios
