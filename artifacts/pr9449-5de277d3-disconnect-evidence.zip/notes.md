# Notes: pr9449_disconnect_atomicity_5de277d3

## Run Information
- **Run ID:** `pr9449_disconnect_atomicity_5de277d3-001-20260827T210317`
- **Iteration:** 1
- **Bundle Version:** 1.2.0
- **Timestamp:** 2026-08-27T21:03:17.962476+00:00

## Evidence Integrity
- All files in this bundle have corresponding `.sha256` checksum files
- Checksums use local basename paths so per-file verification works from each artifact directory

## Scenario Summary
- **Total:** 2
- **Passed:** 2
- **Failed:** 0

## Post-Processing Capture Summary
- **Campaigns with capture status:** 1
- **Capture Passed:** 1
- **Capture Failed:** 0

## Warning/Error Summary
- **Server Warnings:** 21 warnings in server.log
- **Warning Parser:** line-level regex `\bWARNING\b|SYSTEM WARNING:` (one count per matching line)
- **Key Warning Categories:**
  - CRITICAL_SAFEGUARD
  - SYSTEM_INSTRUCTION_EMERGENCY_COMPACT
  - ENTITY_TRACKING_CAPPED

## Follow-up Items
<!-- Add any follow-up items, TODOs, or observations here -->

## Additional Context
<!-- Add any additional context that helps understand this test run -->
