# Evidence Package: pr9449_disconnect_atomicity_04a08dd9

## Package Manifest
- **Test Name:** pr9449_disconnect_atomicity_04a08dd9
- **Run ID:** `pr9449_disconnect_atomicity_04a08dd9-001-20260827T203513`
- **Iteration:** 1
- **Bundle Version:** 1.2.0
- **Collected At (UTC):** 2026-08-27T20:35:13.714973+00:00
- **Repository:** worldarchitect.ai
- **Branch:** fix/streaming-disconnect-atomic-rollback
- **Commit:** 04a08dd928a0c6a8bc6316990a9c927b92c6e238
- **Merge Base:** 802d84edfe3fd3beb63d9ccf338f7fc604fbc4ad
- **Commits Ahead of Main:** 11

## Git Provenance
```
.github/workflows/test.yml                         |   4 +-
 mvp_site/llm_parser.py                             | 243 ++++---
 mvp_site/llm_providers/gemini_provider.py          | 419 ++++++++----
 mvp_site/llm_providers/openclaw_provider.py        |  26 +-
 mvp_site/llm_providers/openrouter_provider.py      |  41 +-
 mvp_site/llm_service.py                            | 678 ++++++++++++++++---
 mvp_site/main.py                                   | 286 +++++---
 .../tests/test_gemini_stream_deadline_contract.py  | 717 ++++++++++++++++-----
 .../tests/test_llm_provider_latency_logging.py     |  79 ++-
 mvp_site/tests/test_llm_service_error_handling.py  | 188 ++++++
 mvp_site/tests/test_main_state_helper.py           | 220 +++++++
 .../tests/test_openclaw_provider_streaming_bq.py   |  37 ++
 mvp_site/tests/test_openrouter_provider.py         |  38 ++
 .../tests/test_truncated_narrative_persistence.py  | 257 +++++++-
 testing_mcp/lib/base_test.py                       |  14 +-
 testing_mcp/lib/campaign_utils.py                  | 365 +++++++----
 .../lib/test_campaign_utils_stream_failures.py     | 177 +++++
 .../streaming/streaming_deadline_evidence.py       |  65 +-
 ...t_streaming_code_execution_deadline_evidence.py | 148 +++--
 ...test_streaming_disconnect_atomicity_evidence.py | 344 ++++++++++
 tests/test_ttv_signal_set_policy.py                |  45 +-
 21 files changed, 3562 insertions(+), 829 deletions(-)
```

## Server Runtime
- **Port:** 8074
- **PID:** 1369362
- **Command:** /home/jleechan/projects/wt-streaming-disconnect-rollback/venv/bin/python -m gunicorn mvp_site.main:app --bind 0.0.0.0:8074 --workers 1 --worker-class gthread --threads 4 --timeout 600 --max-requests 0 --access-logfile - --error-logfile - --log-level info

## Environment Variables
- **WORLDAI_DEV_MODE:** true
- **TESTING:** None
- **MOCK_SERVICES_MODE:** false
- **GOOGLE_APPLICATION_CREDENTIALS:** [SET - file:serviceAccountKey.json]
- **WORLDAI_GOOGLE_APPLICATION_CREDENTIALS:** [SET - file:serviceAccountKey.json]
- **FIRESTORE_EMULATOR_HOST:** None
- **PORT:** 8074
- **FIREBASE_PROJECT_ID:** worldarchitecture-ai
- **GEMINI_API_KEY:** [SET - 39 chars]
- **LLM_REQUEST_RESPONSE_CAPTURE_PATH:** /tmp/worldarchitect.ai/fix_streaming-disconnect-atomic-rollback/pr9449_disconnect_atomicity_04a08dd9/iteration_001/llm_request_responses_1787862800849.jsonl
- **HTTP_REQUEST_RESPONSE_CAPTURE_PATH:** /tmp/worldarchitect.ai/fix_streaming-disconnect-atomic-rollback/pr9449_disconnect_atomicity_04a08dd9/iteration_001/http_request_responses_1787862800849.jsonl
- **GEMINI_HTTP_REQUEST_RESPONSE_CAPTURE_PATH:** /tmp/worldarchitect.ai/fix_streaming-disconnect-atomic-rollback/pr9449_disconnect_atomicity_04a08dd9/iteration_001/gemini_http_request_responses_1787862800849.jsonl
- **MCP_TEST_PROVIDER_HTTP_CAPTURE_PATH:** /tmp/worldarchitect.ai/fix_streaming-disconnect-atomic-rollback/pr9449_disconnect_atomicity_04a08dd9/iteration_001/provider_http_request_responses_1787862800849.jsonl

## Files in This Bundle
- `README.md` - This manifest
- `methodology.md` - Testing methodology
- `evidence.md` - Evidence summary with Claim→Artifact Map and Coverage Matrix
- `notes.md` - Additional context, TODOs, follow-ups
- `metadata.json` - Machine-readable metadata
- `assertions.json` - Strict before/after parity assertions (if present)
- `run.json` - Test results
    - `streaming_evidence.json` - Normalized streaming evidence summary
    - `request_responses.jsonl` - Raw MCP request/response payloads (if present)
    - `llm_request_responses.jsonl` - Raw LLM request/response payloads (if present)
    - `http_request_responses.jsonl` - Raw local-server HTTP request/response payloads (if present)
    - `gemini_http_request_responses.jsonl` - Raw Gemini transport HTTP traces (if present)
    - `artifacts/` - Additional evidence files
