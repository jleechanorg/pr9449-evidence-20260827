# Evidence Summary: pr9449_disconnect_atomicity_04a08dd9

## Test Results
- **Total Scenarios:** 2
- **Scenario Validation Passed:** 2
- **Scenario Validation Failed:** 0
- **Scenario Validation Pass Rate:** 100.0%
- **Raw LLM Layer Passed:** 1/1 (100.0%)

- **Post-Processing Campaign Capture Passed:** 1
- **Post-Processing Campaign Capture Failed:** 0
- **Post-Processing Campaign Capture Pass Rate:** 100.0%
## Scenario Results

### disconnect_before_terminal_commit
- **Status:** ✅ PASS
- **Campaign ID:** `RbTZ5QaJkXbrNY1gIWNM`

### EVIDENCE_SIGNATURE_GUARD
- **Status:** ✅ PASS

## Provenance Chain
- **Git HEAD:** `04a08dd928a0c6a8bc6316990a9c927b92c6e238`
- **Test Timestamp:** `2026-08-27T20:35:13.714973+00:00`
- **Server PID:** `1369362`


## Claim → Artifact Map

| Claim | File | Key Field(s) |
|-------|------|--------------|
| Scenario validation passed: 2/2 | run.json | scenarios[*].passed, scenarios[*].errors |
| Campaign post-processing capture passed: 1/1 | run.json | campaign_capture_status[*].status |
| Streaming evidence normalized | streaming_evidence.json | summary.*, scenarios[*].chunk_count_observed |
| Bundle artifact inventory | artifacts/collection_log.txt | core_files, jsonl_captures, campaigns_dir |
| MCP request/response captured | request_responses.jsonl | Full request/response pairs |
| Local server HTTP request/response captured | http_request_responses.jsonl | http_request/http_response entries |
| LLM request/response stream captured | llm_request_responses.jsonl | request/response entries (type field) |
| Provider HTTP transport captured | provider_http_request_responses.jsonl | http_request/http_response/transport_error entries |
| Server execution log | artifacts/server.log | Raw server output |
| Git provenance | metadata.json | git_provenance.git_head = `04a08dd9...` |
| Test/harness-produced artifact: disconnect_capture.json | disconnect_capture.json | (see file for structure) |
| Test/harness-produced artifact: http_request_responses_1787862800849.jsonl | http_request_responses_1787862800849.jsonl | (see file for structure) |
| Test/harness-produced artifact: llm_request_responses_1787862800849.jsonl | llm_request_responses_1787862800849.jsonl | (see file for structure) |
| Test/harness-produced artifact: pr9449_disconnect_atomicity_04a08dd9.cast | pr9449_disconnect_atomicity_04a08dd9.cast | (see file for structure) |
| Test/harness-produced artifact: provider_http_request_responses_1787862800849.jsonl | provider_http_request_responses_1787862800849.jsonl | (see file for structure) |

## Coverage Matrix

| Scenario | Status | Campaign ID |
|----------|--------|-------------|
| disconnect_before_terminal_commit | ✅ Pass | `RbTZ5QaJ...` |
| EVIDENCE_SIGNATURE_GUARD | ✅ Pass | N/A |

## Evidence Integrity

- All files in this bundle have corresponding `.sha256` checksum files
- Checksums use local basename paths so per-file verification works from each artifact directory

- ⚠️ Server warnings detected (see artifacts/server.log)
- Warning: CRITICAL_SAFEGUARD
- Warning: SYSTEM_INSTRUCTION_EMERGENCY_COMPACT
- Warning: ENTITY_TRACKING_CAPPED


## What This Evidence Proves vs. Does NOT Prove

**Proves**:
- Core logic and scenario validation for pr9449_disconnect_atomicity_04a08dd9
- Scenario execution pass rates (2/2)

**Does NOT Prove**:
- Production server behavior (tested on local server unless otherwise noted)
- Performance under load (single-request tests)
- Edge cases not covered by scenarios

## Claim → Artifact Map (Post-Finalization Addendum)

Files below were written after create_evidence_bundle() returned and
are added here by finalize_late_evidence_artifacts() so every
top-level artifact is traceable from evidence.md.

| Claim | File | Key Field(s) |
|-------|------|--------------|
| Test/harness-produced artifact: replay_fixture_source_manifest.json | replay_fixture_source_manifest.json | (see file for structure) |
| Test/harness-produced artifact: test_console_output.txt | test_console_output.txt | (see file for structure) |
