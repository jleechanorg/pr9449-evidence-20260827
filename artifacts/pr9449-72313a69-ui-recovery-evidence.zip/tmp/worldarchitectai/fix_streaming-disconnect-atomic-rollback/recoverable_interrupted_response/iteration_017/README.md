# Evidence Package: recoverable_interrupted_response

## Package Manifest
- **Test Name:** recoverable_interrupted_response
- **Run ID:** `recoverable_interrupted_response-017-20260831T045936`
- **Iteration:** 17
- **Bundle Version:** 1.2.0
- **Collected At (UTC):** 2026-08-31T04:59:36.887857+00:00
- **Repository:** worldarchitect.ai
- **Branch:** fix/streaming-disconnect-atomic-rollback
- **Commit:** 72313a69e0c8938839e10d1c1b1966ef0206ed3c
- **Merge Base:** 7b56c36b243901b52fa2805fcea7896c95293bc6
- **Commits Ahead of Main:** 47

## Git Provenance
```
.claude/commands/document-standards.md             |   8 +
 .claude/skills/document-standards/SKILL.md         | 313 +++++++++
 .codex/skills/document-standards                   |   1 +
 .github/workflows/comment-router.yml               |   5 +-
 .../2026-08-30-recoverable-interrupted-response.md |  86 +++
 ...8-30-recoverable-interrupted-response-design.md |  78 +++
 mvp_site/constants.py                              |  26 +-
 mvp_site/firestore_service.py                      | 560 +++++++++++++++-
 mvp_site/frontend_v1/app.js                        | 172 ++++-
 mvp_site/frontend_v1/js/streaming.js               | 182 ++++-
 mvp_site/llm_parser.py                             | 450 ++++++++-----
 mvp_site/llm_providers/gemini_provider.py          | 444 ++++++++----
 .../openai_compatible_provider_core.py             | 168 ++++-
 mvp_site/llm_providers/openclaw_provider.py        | 112 +++-
 mvp_site/llm_providers/openrouter_provider.py      |  77 ++-
 mvp_site/llm_service.py                            | 740 ++++++++++++++++++--
 mvp_site/main.py                                   | 451 ++++++++++---
 mvp_site/session_header_utils.py                   |  18 +-
 .../frontend/test_app_js_structured_fields.js      |  19 +-
 .../tests/frontend/test_load_finish_no_scroll.py   |   9 +-
 .../test_recoverable_interrupted_response.js       | 164 +++++
 mvp_site/tests/test_avatar_api_unit.py             |  17 +-
 .../tests/test_gemini_stream_deadline_contract.py  | 743 ++++++++++++++++-----
 mvp_site/tests/test_interrupted_turn_drafts.py     | 448 +++++++++++++
 .../tests/test_interrupted_turn_recovery_route.py  | 383 +++++++++++
 mvp_site/tests/test_level_up_lean_v2_5.py          |   4 +-
 .../tests/test_llm_provider_latency_logging.py     |  79 ++-
 mvp_site/tests/test_llm_service_context.py         | 119 +++-
 mvp_site/tests/test_llm_service_error_handling.py  | 419 ++++++++++++
 mvp_site/tests/test_main_state_helper.py           | 295 ++++++++
 .../tests/test_openai_compatible_provider_core.py  | 117 +++-
 .../tests/test_openclaw_provider_streaming_bq.py   | 102 +++
 mvp_site/tests/test_openrouter_provider.py         | 158 +++++
 mvp_site/tests/test_rewards_engine_wiring.py       |  18 +-
 mvp_site/tests/test_session_header_enrichment.py   |  16 +-
 mvp_site/tests/test_session_header_gold.py         |  10 +-
 .../tests/test_truncated_narrative_persistence.py  | 533 +++++++++++++--
 ...nterrupted-response-goal-ironclad-2026-08-30.md |  62 ++
 testing_mcp/lib/base_test.py                       |  14 +-
 testing_mcp/lib/campaign_utils.py                  | 365 ++++++----
 .../lib/test_campaign_utils_stream_failures.py     | 177 +++++
 .../streaming/streaming_deadline_evidence.py       |  68 +-
 ...t_streaming_code_execution_deadline_evidence.py | 209 ++++--
 ...test_streaming_disconnect_atomicity_evidence.py | 640 ++++++++++++++++++
 testing_ui/streaming/base.py                       |  31 +-
 .../test_recoverable_interrupted_response.py       | 681 +++++++++++++++++++
 tests/test_ci_checkout_depth_policy.py             |  20 +
 tests/test_mcp_smoke_workflow_dispatch.py          |  61 ++
 48 files changed, 8793 insertions(+), 1079 deletions(-)
```

## Server Runtime
- **Port:** 56799
- **PID:** 3950980
- **Command:** /home/jleechan/projects/wt-streaming-disconnect-rollback/venv/bin/python -m guni

## Environment Variables
- **WORLDAI_DEV_MODE:** true
- **TESTING:** None
- **MOCK_SERVICES_MODE:** false
- **GOOGLE_APPLICATION_CREDENTIALS:** [SET - file:serviceAccountKey.json]
- **WORLDAI_GOOGLE_APPLICATION_CREDENTIALS:** [SET - file:serviceAccountKey.json]
- **FIRESTORE_EMULATOR_HOST:** None
- **PORT:** 56799
- **FIREBASE_PROJECT_ID:** worldarchitecture-ai
- **GEMINI_API_KEY:** [SET - 39 chars]
- **LLM_REQUEST_RESPONSE_CAPTURE_PATH:** /tmp/worldarchitectai/fix_streaming-disconnect-atomic-rollback/recoverable_interrupted_response/iteration_017/llm_request_responses_1788152261493.jsonl
- **HTTP_REQUEST_RESPONSE_CAPTURE_PATH:** /tmp/worldarchitectai/fix_streaming-disconnect-atomic-rollback/recoverable_interrupted_response/iteration_017/http_request_responses_1788152261493.jsonl
- **GEMINI_HTTP_REQUEST_RESPONSE_CAPTURE_PATH:** /tmp/worldarchitectai/fix_streaming-disconnect-atomic-rollback/recoverable_interrupted_response/iteration_017/gemini_http_request_responses_1788152261493.jsonl
- **MCP_TEST_PROVIDER_HTTP_CAPTURE_PATH:** /tmp/worldarchitectai/fix_streaming-disconnect-atomic-rollback/recoverable_interrupted_response/iteration_017/provider_http_request_responses_1788152261493.jsonl

## Files in This Bundle
- `README.md` - This manifest
- `methodology.md` - Testing methodology
- `evidence.md` - Evidence summary with Claim→Artifact Map and Coverage Matrix
- `notes.md` - Additional context, TODOs, follow-ups
- `metadata.json` - Machine-readable metadata
- `assertions.json` - Strict before/after parity assertions (if present)
- `run.json` - Test results
    - `streaming_evidence.json` - Normalized streaming evidence summary
    - `request_responses.jsonl` - Raw MCP request/response payloads (if present)
    - `llm_request_responses.jsonl` - Raw LLM request/response payloads (if present)
    - `http_request_responses.jsonl` - Raw local-server HTTP request/response payloads (if present)
    - `gemini_http_request_responses.jsonl` - Raw Gemini transport HTTP traces (if present)
    - `artifacts/` - Additional evidence files
