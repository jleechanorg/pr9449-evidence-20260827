# Real Provider-Stream Deadline & Cancellation Evidence (rev-eh2gp)

## Execution Summary
- **Git Head SHA**: `5de277d3eabbbcc08a031f35ad8408c6b3371f92`
- **Request ID**: `req-deadline-e55152c157ff`
- **Model**: `gemini-3-flash-preview`
- **Provider Type**: `gemini_sdk`
- **AGY Opt-Out**: `AGY_OPT_OUT_FOR_GEMINI_SDK_ONLY=1` — Direct Gemini SDK is required because AGY does not expose provider-level streaming and cancellation telemetry.
- **Elapsed Duration**: `0.465s` (Bound: `0.600s`)
- **Cancellation Requested**: `True` (persisted telemetry)
- **Cancellation Acknowledged**: `False`
- **Persisted BQ Evidence**: `True`
- **Timestamp (UTC)**: `2026-08-27T21:01:53.425028+00:00`

## Verified Claims
| Claim | Layer | Artifact | Verdict |
|---|---|---|---|
| Stream Deadline Prompt Termination | Layer 2 real-callstack + real-LLM | `raw_stream.log` | PROVEN |
| Truthful Cancellation Telemetry | Layer 2 real-BQ | `artifacts/bq_llm_payloads_rows.json` | PROVEN |
| BigQuery Terminal Telemetry (`circuit_breaker_tripped:deadline`) | Layer 2 real-BQ | `artifacts/bq_llm_payloads_rows.json` | PROVEN |
| Monotonic Phase Timestamps | Layer 2 real-BQ | `artifacts/bq_llm_payloads_rows.json` | PROVEN |
| Latency Context Correlation | Layer 2 real-BQ | `artifacts/bq_latency_metrics_rows.json` | PROVEN |

## Telemetry Payload
```json
[
  {
    "agent": "gemini_provider.stream",
    "campaign_id": "camp-deadline-44836b87",
    "event_type": "gameplay_streaming",
    "extra_json": "{\"request_json_source_bytes\": 1598, \"request_json_source_sha256\": \"ef78a8aed86542c58ded4dbf3d66034056f78f2a2ac54b912976d67a596ed987\", \"request_json_stored_bytes\": 1598, \"request_json_stored_sha256\": \"ef78a8aed86542c58ded4dbf3d66034056f78f2a2ac54b912976d67a596ed987\", \"request_json_storage_transformed\": false, \"response_text_source_bytes\": 0, \"response_parts_json_source_bytes\": 0, \"provider_type\": \"gemini_sdk\", \"request_id\": \"req-deadline-e55152c157ff\", \"agent\": \"gemini_provider.stream\", \"model\": \"gemini-3-flash-preview\", \"campaign_id\": \"camp-deadline-44836b87\", \"path\": \"gemini_provider.stream\", \"stream\": true, \"chunks_seen\": 0, \"request_sent_at\": 1787864502.3617172, \"deadline_evaluated_at\": 1787864502.3617442, \"terminal_at\": 1787864502.812705, \"terminal_outcome\": \"deadline\", \"system_instruction_sha256\": null, \"system_instruction_bytes\": 0, \"system_instruction_chars\": 0, \"system_instruction_tokens_est\": 0, \"story_history_entry_count\": 0, \"story_tokens_est\": 0, \"envelope_tokens_est\": 21, \"estimated_input_tokens\": 21, \"cancelled_at\": 1787864502.61207, \"cancellation_acknowledged\": false, \"cancellation_requested_at\": 1787864502.61207, \"circuit_breaker_trip_reason\": \"elapsed_seconds=0.3>0.25\", \"finish_reason\": \"circuit_breaker_tripped:deadline\", \"capture_source\": \"reconstructed_non_authoritative\"}",
    "finish_reason": "circuit_breaker_tripped:deadline",
    "ingested_at": "2026-08-27 21:01:42",
    "model": "gemini-3-flash-preview",
    "output_tokens": null,
    "prompt_tokens": null,
    "request_id": "req-deadline-e55152c157ff"
  }
]
```

## Persisted Latency Metrics
```json
[
  {
    "campaign_id": "camp-deadline-44836b87",
    "extra_json": "{\"stream\": true, \"request_id\": \"req-deadline-e55152c157ff\", \"finish_reason\": \"circuit_breaker_tripped:deadline\", \"terminal_outcome\": \"deadline\", \"request_sent_at\": 1787864502.3617172, \"deadline_evaluated_at\": 1787864502.3617442, \"terminal_at\": 1787864502.812705, \"cancellation_requested_at\": 1787864502.61207, \"cancellation_acknowledged\": false, \"cancelled_at\": 1787864502.61207, \"circuit_breaker_trip_reason\": \"elapsed_seconds=0.3>0.25\"}",
    "ingested_at": "2026-08-27 21:01:43",
    "model": "gemini-3-flash-preview",
    "operation": "llm_call",
    "success": "false"
  }
]
```

## What This Evidence Proves
- Real Gemini streaming call decoupling allows the consumer to abort at deadline without waiting on the provider iterator.
- Persisted telemetry records the cancellation request and preserves the provider cleanup acknowledgement truthfully. This run does not claim transport cleanup when that acknowledgement is `false`.
- Persisted telemetry captures circuit breaker deadline trip without misclassifying as normal STOP completion.
- Distinct phase timestamps trace request lifecycle.

## What This Evidence Does NOT Prove
- Does not prove that Gemini provider will never experience server-side network lag or stall.
- Does not guarantee external network transport availability.
